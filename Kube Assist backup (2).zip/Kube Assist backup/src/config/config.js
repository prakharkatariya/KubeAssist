const CHAT_API_URL = process.env.REACT_APP_CHAT_API_URL || 'https://kube-chat.api.carelon.com';

export const CHAT_STREAM_ENDPOINT = `${CHAT_API_URL}/api/chat`;
