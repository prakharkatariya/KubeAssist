function Chart() {
  return <div>Chart component</div>;
}

export default Chart;
