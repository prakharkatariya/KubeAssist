import { User } from './user';

export interface AppStateType {
  sessionId: string;
}
