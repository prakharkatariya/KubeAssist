import { ChatApi } from './chat';

const apis = {
  chat: new ChatApi(),
};

export default apis;
