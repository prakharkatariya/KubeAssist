import Chart from "@components/dashboard/Chart";

export default function Dashboard() {
  return <div>
    Dashboard page...
    <Chart/>
  </div>;
}
