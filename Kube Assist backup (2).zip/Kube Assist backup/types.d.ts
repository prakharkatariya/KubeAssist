declare global {
  interface Window {}
}
