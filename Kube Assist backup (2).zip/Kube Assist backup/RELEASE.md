# Changelog

## [v0.1.0] - 02.07.2025

### Added

- Initialize
